"""Generate a seamless 32 s eerie ambient drone loop (mono 16-bit WAV).

All tonal frequencies are integer multiples of 1/DUR so the loop is
phase-continuous.  The noise bed uses a crossfade loop.
"""
import math, random, struct, os

SR = 22050
DUR = 32.0
N = int(SR * DUR)
random.seed(31)

buf = [0.0] * N

# ---------------------------------------------------------------- drone ----
# every freq must satisfy f * DUR == integer  ->  f = k / DUR
drone = [
    (55.0,    0.150),   # A1   root
    (55.3125, 0.130),   # detuned twin -> slow beating
    (82.5,    0.070),   # E2   fifth
    (58.25,   0.045),   # minor second, sour interval
    (110.0,   0.030),
]
w0 = 2 * math.pi / SR
for f, amp in drone:
    w = 2 * math.pi * f / SR
    ph = random.random() * 6.283
    for i in range(N):
        buf[i] += amp * math.sin(w * i + ph)

# slow breathing swell: 2 cycles per loop -> seamless
for i in range(N):
    t = i / SR
    buf[i] *= 0.72 + 0.28 * (0.5 + 0.5 * math.sin(2 * math.pi * (1.0 / 16.0) * t))

# faint high shimmer, very quiet
for f, amp in [(660.0, 0.010), (880.0, 0.008), (1320.0, 0.005)]:
    w = 2 * math.pi * f / SR
    for i in range(N):
        buf[i] += amp * math.sin(w * i)

# ---------------------------------------------------------------- bells ----
# distant inharmonic bells; each dies well before the loop point
def bell(t0, f0, amp):
    dur = 7.0
    n = int(dur * SR)
    start = int(t0 * SR)
    partials = [1.0, 2.76, 5.40, 8.93, 13.3]
    gains = [1.0, 0.55, 0.32, 0.18, 0.10]
    decays = [1.6, 2.4, 3.2, 4.2, 5.0]
    for k, (p, g, dk) in enumerate(zip(partials, gains, decays)):
        w = 2 * math.pi * f0 * p / SR
        for i in range(n):
            if start + i >= N:
                break
            t = i / SR
            env = math.exp(-t / dk) * (1.0 - math.exp(-t * 90.0))
            buf[start + i] += amp * g * env * math.sin(w * i)

bell(3.0,  146.83, 0.075)   # D3
bell(12.0, 130.81, 0.060)   # C3
bell(21.0, 116.54, 0.055)   # A#2

# ----------------------------------------------------------------- wind ----
C = int(2.0 * SR)                 # crossfade length
raw = [random.uniform(-1, 1) for _ in range(N + C)]
lp = [0.0] * (N + C)
prev = 0.0
for i in range(N + C):            # two cascaded one-pole lowpasses
    prev += 0.035 * (raw[i] - prev)
    lp[i] = prev
prev2 = 0.0
for i in range(N + C):
    prev2 += 0.035 * (lp[i] - prev2)
    lp[i] = prev2
for i in range(C):                # crossfade loop
    w = i / C
    buf[i] += 0.85 * (lp[i] * w + lp[N + i] * (1.0 - w))
for i in range(C, N):
    buf[i] += 0.85 * lp[i]

# slow wind gusts (3 cycles per loop)
for i in range(N):
    t = i / SR
    buf[i] *= 1.0 + 0.18 * math.sin(2 * math.pi * (3.0 / DUR) * t + 1.2)

# -------------------------------------------------------------- finalise ----
peak = max(abs(v) for v in buf)
scale = 0.30 / peak          # quiet background bed; heartbeat sits on top
data = b''.join(
    struct.pack('<h', int(max(-1.0, min(1.0, v * scale)) * 32767)) for v in buf
)
hdr = (b'RIFF' + struct.pack('<I', 36 + len(data)) + b'WAVEfmt ' +
       struct.pack('<IHHIIHH', 16, 1, 1, SR, SR * 2, 2, 16) +
       b'data' + struct.pack('<I', len(data)))
os.makedirs('audio', exist_ok=True)
with open('audio/bgm.wav', 'wb') as f:
    f.write(hdr + data)
print('bgm.wav written, %.1f s, %d bytes' % (DUR, len(hdr + data)))
